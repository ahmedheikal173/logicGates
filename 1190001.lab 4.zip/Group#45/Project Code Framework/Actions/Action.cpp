#include "Action.h"

void Action::AddGate(Gate* x)
{
	Gateso[compno++] = x;
}


